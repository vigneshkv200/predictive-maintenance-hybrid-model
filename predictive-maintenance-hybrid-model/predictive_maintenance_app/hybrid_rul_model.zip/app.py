# app.py — Predictive Maintenance demo (Full version)
# Paste whole file into predictive_maintenance_app/app.py

import streamlit as st
import pandas as pd
import numpy as np
import os
import pickle
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

st.set_page_config(layout="wide", page_title="Predictive Maintenance — Hybrid Demo")

# -----------------------
# Utilities / constants
# -----------------------
SEQ_LENGTH = 30
SENSOR_COLS = ["op1", "op2", "op3"] + [f"s{i}" for i in range(1, 22)]  # total 24 feature names expected
EXPECTED_FEATURE_COUNT = len(SENSOR_COLS)  # 24

@st.cache_resource
def load_artifacts(base_folder="."):
    """Try loading models and scaler. Return dict with keys (lstm, autoencoder, hybrid, scaler, threshold) or None."""
    out = {"lstm": None, "autoencoder": None, "hybrid": None, "scaler": None, "threshold": None}
    try:
        p = os.path.join(base_folder, "lstm_rul_model.keras")
        if os.path.exists(p):
            out["lstm"] = load_model(p)
    except Exception as e:
        st.warning(f"Could not load LSTM model: {e}")
    try:
        p = os.path.join(base_folder, "autoencoder_model.keras")
        if os.path.exists(p):
            out["autoencoder"] = load_model(p)
    except Exception as e:
        st.warning(f"Could not load Autoencoder model: {e}")
    try:
        p = os.path.join(base_folder, "hybrid_rul_model.keras")
        if os.path.exists(p):
            out["hybrid"] = load_model(p)
    except Exception as e:
        st.warning(f"Could not load Hybrid model: {e}")
    try:
        p = os.path.join(base_folder, "scaler.pkl")
        if os.path.exists(p):
            with open(p, "rb") as f:
                out["scaler"] = pickle.load(f)
    except Exception as e:
        st.warning(f"Could not load scaler.pkl: {e}")
    # threshold: try threshold.txt first, then threshold file with name 'threshold'
    for name in ("threshold.txt", "threshold"):
        p = os.path.join(base_folder, name)
        if os.path.exists(p):
            try:
                with open(p, "r") as f:
                    t = float(f.read().strip())
                    out["threshold"] = t
            except Exception as e:
                st.warning(f"Could not read {name}: {e}")
            break
    return out

def ensure_sensor_columns(df: pd.DataFrame):
    """Try to coerce column names to expected sensor columns.
       Accepts: full NASA format with unit,time,op1,op2,op3,s1..s21
       Or accepts bare sensor columns order op1,op2,op3,s1..s21 without unit/time.
    """
    cols = list(df.columns)
    # if dataframe already has SENSOR_COLS as subset or exact order, align
    if all(c in cols for c in SENSOR_COLS):
        # reorder to SENSOR_COLS
        return df[SENSOR_COLS].copy()
    # if it has columns like col0.. etc (no headers), try to assume correct order:
    if df.shape[1] == EXPECTED_FEATURE_COUNT:
        df2 = df.copy()
        df2.columns = SENSOR_COLS
        return df2
    # if NASA format (unit,time, op1, op2, op3, s1..s21), try to detect
    if df.shape[1] >= EXPECTED_FEATURE_COUNT + 2 and "unit" in cols and "time" in cols:
        # attempt
        keep = []
        for c in SENSOR_COLS:
            if c in cols:
                keep.append(c)
            else:
                # try to map by position: op1->col2, ...
                pass
        if len(keep) == EXPECTED_FEATURE_COUNT:
            return df[keep].copy()
    # cannot coerce
    raise ValueError(f"Input data doesn't contain sensor columns. Found columns: {cols}")

def create_last_sequences_for_units(df: pd.DataFrame, seq_length=SEQ_LENGTH):
    """
    For NASA-style data (with 'unit' and 'time'), create one sequence per unit
    by taking the last seq_length rows for that unit (pad by repeating first row if needed).
    Returns X_last (n_units, seq_length, features) and a list of (unit, last_time).
    """
    if "unit" not in df.columns or "time" not in df.columns:
        raise ValueError("create_last_sequences_for_units expects 'unit' and 'time' columns in dataframe.")
    units = df["unit"].unique()
    Xs = []
    meta = []
    for u in units:
        u_df = df[df["unit"] == u].sort_values("time")
        features = ensure_sensor_columns(u_df)  # this will select sensor columns
        arr = features.values
        if arr.shape[0] >= seq_length:
            seq = arr[-seq_length:]
        else:
            # pad by repeating the first row to reach seq_length
            pad_count = seq_length - arr.shape[0]
            pad = np.repeat(arr[0:1, :], pad_count, axis=0)
            seq = np.vstack([pad, arr])
        Xs.append(seq)
        meta.append((int(u), int(u_df["time"].max())))
    X = np.array(Xs, dtype=np.float32)
    return X, meta

def create_sequence_from_single_row(row: np.ndarray, seq_length=SEQ_LENGTH):
    """Given a single sensor row (1D length EXPECTED_FEATURE_COUNT), create a sequence
       by repeating it seq_length times (simple demo strategy)."""
    row = np.asarray(row).reshape(1, -1)
    seq = np.repeat(row, seq_length, axis=0)
    return seq[np.newaxis, ...].astype(np.float32)  # shape (1, seq_length, features)

def compute_anomaly_scores(autoencoder, scaler, df_sensors: pd.DataFrame):
    """
    Compute per-row anomaly score using autoencoder.
    We assume scaler.transform was applied already (or compute inside).
    We'll compute reconstruction MSE across features for each sample.
    """
    X = df_sensors.values.astype(np.float32)
    if scaler is not None:
        X_scaled = scaler.transform(df_sensors.values)
    else:
        X_scaled = X
    # predict
    recon = autoencoder.predict(X_scaled, verbose=0)
    mse = np.mean((X_scaled - recon) ** 2, axis=1)
    return mse

def safe_predict_lstm(lstm, seq_array):
    """seq_array shape: (n, seq_length, features)"""
    if lstm is None:
        raise ValueError("LSTM model not loaded.")
    preds = lstm.predict(seq_array, verbose=0)
    # flatten if shape (n,1) or (n,)
    return preds.reshape(-1)

def safe_predict_hybrid(hybrid, hybrid_input):
    """hybrid_input shape: (n, k)"""
    if hybrid is None:
        raise ValueError("Hybrid model not loaded.")
    preds = hybrid.predict(hybrid_input, verbose=0)
    return preds.reshape(-1)

# -----------------------
# UI: sidebar + header
# -----------------------
st.title(" Predictive Maintenance — Hybrid RUL + Anomaly Demo (Full)")
st.write("Demo app: LSTM RUL + Autoencoder anomaly -> Hybrid RUL. Use your saved models and scaler in this folder.")

base_folder = st.sidebar.text_input("Models folder (leave blank = current folder)", value=".")
artifacts = load_artifacts(base_folder)

st.sidebar.markdown("### Loaded artifacts")
st.sidebar.write({
    "LSTM model": bool(artifacts["lstm"]),
    "Autoencoder": bool(artifacts["autoencoder"]),
    "Hybrid model": bool(artifacts["hybrid"]),
    "scaler.pkl": bool(artifacts["scaler"]),
    "threshold": artifacts["threshold"] is not None
})

st.sidebar.markdown("---")
st.sidebar.write("Expected sensor columns (in order):")
st.sidebar.write(SENSOR_COLS)

# -----------------------
# Controls: upload & manual input
# -----------------------
st.header("1) Provide input data")
col1, col2 = st.columns(2)

with col1:
    st.subheader("Upload dataset (CSV)")
    uploaded = st.file_uploader("Upload a CSV (NASA turbofan format or sensor-only rows). If NASA format, include 'unit' and 'time' columns.", type=["csv", "txt"])
    st.markdown("Examples: train_FD001.txt (converted to CSV), or a CSV file with columns op1,op2,op3,s1..s21.")
with col2:
    st.subheader("Or: Manual single-row input")
    manual_mode = st.checkbox("Use manual sensor input (single row)", value=False)
    manual_inputs = {}
    if manual_mode:
        st.markdown("Enter sensor values (or leave blank to use zero). Values should be already in same scale as training if you want realistic results (app will scale if scaler available).")
        # show compact two rows of inputs
        cols = st.columns(6)
        all_names = SENSOR_COLS
        for i, name in enumerate(all_names):
            v = cols[i % 6].text_input(name, value="", key=f"m_{name}")
            manual_inputs[name] = v

st.markdown("---")

# -----------------------
# Preprocess / read
# -----------------------
df_input = None
if uploaded:
    try:
        df_input = pd.read_csv(uploaded)
    except Exception:
        # try whitespace separated (NASA original)
        try:
            uploaded.seek(0)
            df_input = pd.read_csv(uploaded, sep="\s+", header=None)
            st.info("Loaded whitespace-separated file as fallback; check column mapping.")
        except Exception as e:
            st.error(f"Can't read uploaded file: {e}")
            df_input = None

if manual_mode:
    # create a single-row dataframe
    vals = []
    for c in SENSOR_COLS:
        s = manual_inputs.get(c, "")
        try:
            v = float(s) if s != "" else 0.0
        except:
            v = 0.0
        vals.append(v)
    df_input = pd.DataFrame([vals], columns=SENSOR_COLS)

if df_input is None:
    st.info("Upload a CSV or enable manual input to proceed.")
    st.stop()

st.write("Preview of input (first 5 rows):")
st.dataframe(df_input.head())

# -----------------------
# Run predictions
# -----------------------
st.header("2) Run predictions")
run = st.button("Run inference (LSTM + Autoencoder + Hybrid)")

if run:
    # 1) If uploaded file contains unit/time, we will handle per-unit last seq
    has_unit_time = ("unit" in df_input.columns and "time" in df_input.columns)
    # Prepare sensor-only dataframe for anomaly (per-row) calculation
    try:
        df_sensors = ensure_sensor_columns(df_input.copy())
    except Exception as e:
        st.error(f"Could not map sensor columns: {e}")
        st.stop()

    # scale sensor features if scaler exists
    scaler = artifacts["scaler"]
    if scaler is not None:
        try:
            sensors_scaled = pd.DataFrame(scaler.transform(df_sensors.values), columns=df_sensors.columns)
        except Exception as e:
            st.error(f"Scaler exists but failed to transform inputs: {e}")
            sensors_scaled = df_sensors.copy()
    else:
        sensors_scaled = df_sensors.copy()

    # 2) Autoencoder anomaly score per row
    if artifacts["autoencoder"] is not None:
        try:
            anomaly_scores = compute_anomaly_scores(artifacts["autoencoder"], scaler, df_sensors)
        except Exception as e:
            st.error(f"Autoencoder inference error: {e}")
            anomaly_scores = np.zeros(len(df_sensors))
    else:
        st.warning("Autoencoder model not loaded — anomaly score = 0 used.")
        anomaly_scores = np.zeros(len(df_sensors))

    # determine threshold
    threshold = artifacts["threshold"]
    if threshold is None:
        # fallback: set threshold = mean + 2*std of anomaly scores
        threshold = float(np.mean(anomaly_scores) + 2.0 * np.std(anomaly_scores))
        st.info(f"No threshold file found — using heuristic threshold = mean + 2*std = {threshold:.6f}")

    is_anomaly = anomaly_scores > threshold

    # 3) LSTM predictions
    lstm_preds = None
    meta = None
    if has_unit_time:
        # prepare last sequences per unit
        try:
            # we need scaled sensor values for sequence creation and LSTM expects scaled features
            # create df_with_unit that includes sensor columns + unit/time if present
            df_for_seq = df_input.copy()
            for c in SENSOR_COLS:
                if c not in df_for_seq.columns:
                    # if missing sensors, insert zeros
                    df_for_seq[c] = 0.0
            # if scaler exists, transform sensor columns in df_for_seq
            if scaler is not None:
                df_for_seq[SENSOR_COLS] = scaler.transform(df_for_seq[SENSOR_COLS].values)
            X_last, meta = create_last_sequences_for_units(df_for_seq, seq_length=SEQ_LENGTH)
            if artifacts["lstm"] is not None:
                lstm_preds = safe_predict_lstm(artifacts["lstm"], X_last)
            else:
                st.warning("LSTM not loaded — cannot compute LSTM RULs for multi-unit dataset.")
                lstm_preds = np.zeros(X_last.shape[0])
        except Exception as e:
            st.error(f"Failed preparing sequences for units: {e}")
            lstm_preds = np.zeros(len(df_sensors))
    else:
        # single-row or dataset without unit/time: create seq by repeating last row (simple demo)
        try:
            if scaler is not None:
                sample = scaler.transform(df_sensors.values)
            else:
                sample = df_sensors.values
            # We'll make a sequence per row by repeating that row SEQ_LENGTH times
            X_seq = np.array([np.repeat(sample[i:i+1, :], SEQ_LENGTH, axis=0) for i in range(sample.shape[0])], dtype=np.float32)
            if artifacts["lstm"] is not None:
                lstm_preds = safe_predict_lstm(artifacts["lstm"], X_seq)
            else:
                st.warning("LSTM not loaded — cannot compute LSTM RULs.")
                lstm_preds = np.zeros(X_seq.shape[0])
            # meta: make placeholders
            meta = [("row", i) for i in range(len(lstm_preds))]
        except Exception as e:
            st.error(f"Error running LSTM on input: {e}")
            lstm_preds = np.zeros(len(df_sensors))
            meta = [("row", i) for i in range(len(df_sensors))]

    # 4) Hybrid: combine anomaly & is_anomaly & lstm_pred into hybrid model input
    hybrid_preds = None
    try:
        # prepare hybrid_input with shape (n,3): [anomaly_score, is_anomaly (0/1), lstm_pred]
        # align lengths: if per-unit case, len(meta)==len(lstm_preds) and anomaly_scores length may be per-row.
        if has_unit_time:
            # we took last sequence per unit, so pick anomaly score of the last row of each unit:
            anomaly_of_last = []
            is_anomaly_last = []
            for (u, t) in meta:
                # find the row index for unit u and max time t
                condition = (df_input["unit"] == u) & (df_input["time"] == t)
                idx = df_input.index[condition]
                if len(idx) >= 1:
                    i0 = idx[-1]
                    anomaly_of_last.append(anomaly_scores[i0])
                    is_anomaly_last.append(int(is_anomaly[i0]))
                else:
                    anomaly_of_last.append(0.0)
                    is_anomaly_last.append(0)
            anomaly_of_last = np.array(anomaly_of_last)
            is_anomaly_last = np.array(is_anomaly_last).astype(float)
            hybrid_input = np.column_stack([anomaly_of_last.reshape(-1,1), is_anomaly_last.reshape(-1,1), lstm_preds.reshape(-1,1)])
        else:
            hybrid_input = np.column_stack([anomaly_scores.reshape(-1,1), is_anomaly.astype(float).reshape(-1,1), lstm_preds.reshape(-1,1)])
        if artifacts["hybrid"] is not None:
            hybrid_preds = safe_predict_hybrid(artifacts["hybrid"], hybrid_input)
        else:
            st.warning("Hybrid model not loaded — hybrid RUL = LSTM RUL used as fallback.")
            hybrid_preds = lstm_preds
    except Exception as e:
        st.error(f"Failed to compute hybrid predictions: {e}")
        hybrid_preds = lstm_preds

    # -----------------------
    # Results presentation
    # -----------------------
    st.header("3) Results")

    # If per-unit mode, make dataframe with meta
    if has_unit_time:
        units = [m[0] for m in meta]
        last_time = [m[1] for m in meta]
        results = pd.DataFrame({
            "unit": units,
            "last_time": last_time,
            "lstm_RUL": lstm_preds,
            "hybrid_RUL": hybrid_preds
        })
        st.subheader("Per-unit last-time predictions (first 20)")
        st.dataframe(results.head(20))
    else:
        # per-row
        out_df = df_sensors.copy()
        out_df["anomaly_score"] = anomaly_scores
        out_df["is_anomaly"] = is_anomaly.astype(int)
        out_df["lstm_RUL"] = lstm_preds
        out_df["hybrid_RUL"] = hybrid_preds
        st.subheader("Per-row results (first 20)")
        st.dataframe(out_df.head(20))

    # show example single-row output for manual case or first row
    st.markdown("### Example outputs (first 5)")
    example_table = (results.head(5) if has_unit_time else out_df.head(5))
    st.table(example_table)

    # Plots
    st.subheader("Plots")
    fig, ax = plt.subplots(1,2, figsize=(12,4))
    if has_unit_time:
        ax[0].plot(results["unit"], results["hybrid_RUL"], marker='o')
        ax[0].set_title("Hybrid RUL per unit (last time)")
        ax[0].set_xlabel("unit")
        ax[0].set_ylabel("RUL")
        # plot anomaly of last rows
        ax[1].bar(results["unit"], results["lstm_RUL"], alpha=0.6, label="LSTM RUL")
        ax[1].bar(results["unit"], results["hybrid_RUL"], alpha=0.4, label="Hybrid RUL")
        ax[1].legend()
        ax[1].set_title("LSTM vs Hybrid RUL")
    else:
        ax[0].plot(out_df["anomaly_score"].values[:200], label="anomaly_score")
        ax[0].set_title("Anomaly scores (first 200 rows)")
        ax[1].plot(out_df["hybrid_RUL"].values[:200], label="hybrid_RUL")
        ax[1].set_title("Hybrid RUL (first 200 rows)")
    st.pyplot(fig)

    st.success("Inference complete ")

# -----------------------
# Rule-based table demo (editable)
# -----------------------
st.header("4) Simple Rule-based Safety Table (editable demo)")
st.write("This is a small demo table you can edit for rules to show on your demo (for instance: safe temperature ranges). It is purely demonstrative — adapt columns to your sensors.")
if "rule_table" not in st.session_state:
    st.session_state.rule_table = pd.DataFrame({
        "Sensor": ["s3", "s7", "op3"],
        "Min (safe)": [0.0, 0.0, 0.0],
        "Max (safe)": [100.0, 1.0, 80.0],
        "Action": ["OK", "Monitor", "Immediate check"]
    })
edited = st.data_editor(st.session_state.rule_table, num_rows="dynamic")
st.write("Use these rules as a demo overlay in your presentation. You can export this table or copy values to show 'rule-based' alerts.")

# -----------------------
# Footer / help
# -----------------------
st.markdown("---")
st.write("Notes:")
st.write("- Ensure models and scaler files are placed inside the folder you selected in the sidebar.")
st.write("- This demo uses simple strategies for single-row sequence building (repeat last row). For production use, compute sequences from actual sensor time-series windows.")
st.write("- For any errors shown by the app, copy the full traceback into the notebook/terminal and I can help fix it.")